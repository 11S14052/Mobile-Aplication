package com.example.wahyunainggolan.paprika;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.astuetz.PagerSlidingTabStrip;

/**
 * Created by Wahyu Nainggolan on 09/09/2018.
 */

public class SampleFragmentPagerAdapter extends FragmentPagerAdapter implements PagerSlidingTabStrip.IconTabProvider {
    final int PAGE_COUNT = 12;
    private String tabTitles[] = new String[] { "New Outlets", "Cashback", "Discount","Nearby", "Restaurant & Cafe", "Snack & Dessert", "Rumah Makan", "Health & Beauty", "Mart", "Entertainment & Leisure", "Others", "FTS" };

    private Integer[] imgid= {
            R.drawable.a,
            R.drawable.b,
            R.drawable.c,
            R.drawable.e,
            R.drawable.f,
            R.drawable.g,
            R.drawable.h,
            R.drawable.i,
            R.drawable.j,
            R.drawable.k,
            R.drawable.l,
            R.drawable.m,

    };

    public SampleFragmentPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public int getCount() {
        return PAGE_COUNT;
    }

    @Override
    public Fragment getItem(int position) {
        return PageFragment.newInstance(position + 1);
    }

    @Override
    public int getPageIconResId(int position) {
        return imgid[position];
    }}