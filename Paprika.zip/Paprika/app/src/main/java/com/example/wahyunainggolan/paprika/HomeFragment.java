package com.example.wahyunainggolan.paprika;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;

import com.astuetz.PagerSlidingTabStrip;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    GridView simpleGrid;
    int logos[] = {R.drawable.logo1, R.drawable.logo2, R.drawable.logo3, R.drawable.logo4,
            R.drawable.logo5, R.drawable.logo6, R.drawable.logo7, R.drawable.logo8,R.drawable.logo9, R.drawable.logo10, R.drawable.logo11, R.drawable.logo12,
            R.drawable.logo13, R.drawable.logo14, R.drawable.logo15, R.drawable.logo16,R.drawable.logo17};
    View rootView;
    private SliderPagerAdapter mAdapter;
    private SliderIndicator mIndicator;
    private SliderView sliderView;
    private LinearLayout mLinearLayout;
    private ActionBar toolbar;

    ArrayList<Integer> images=new ArrayList<Integer>(){
        {
            add(R.drawable.one);
            add(R.drawable.two);
            add(R.drawable.three);
            add(R.drawable.five);
        }};
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_home, container, false);
        sliderView = (SliderView)rootView.findViewById(R.id.sliderView);
        mLinearLayout = (LinearLayout)rootView.findViewById(R.id.pagesContainer);
        ViewPager viewPager = (ViewPager)rootView.findViewById(R.id.viewPager);

        viewPager.setAdapter(new SampleFragmentPagerAdapter(getActivity().getSupportFragmentManager()));
        PagerSlidingTabStrip tabsStrip = (PagerSlidingTabStrip)rootView.findViewById(R.id.tabs);
        tabsStrip.setViewPager(viewPager);


        simpleGrid = (GridView)rootView.findViewById(R.id.simpleGridView); // init GridView
        // Create an object of CustomAdapter and set Adapter to GirdView
        CustomAdapter customAdapter = new CustomAdapter(getActivity().getApplicationContext(), logos);
        simpleGrid.setAdapter(customAdapter);
        // implement setOnItemClickListener event on GridView
        simpleGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                // set an Intent to Another Activity
//                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
//                intent.putExtra("image", logos[position]); // put image data in Intent
//                startActivity(intent); // start Intent
            }
        });

        setupSlider();
        return rootView;
    }


    private void setupSlider() {
        int currImage = 0;
        sliderView.setDurationScroll(800);
        List<Fragment> fragments = new ArrayList<>();
        for (int i = 0; i < images.size(); i++) {
            fragments.add(FragmentSlider.newInstance(String.valueOf(images.get(i))));
        }
        mAdapter = new SliderPagerAdapter(getActivity().getSupportFragmentManager(), fragments);
        sliderView.setAdapter(mAdapter);
        mIndicator = new SliderIndicator(getContext(), mLinearLayout, sliderView, R.drawable.indicator_circle);
        mIndicator.setPageCount(fragments.size());
        mIndicator.show();
    }


}
