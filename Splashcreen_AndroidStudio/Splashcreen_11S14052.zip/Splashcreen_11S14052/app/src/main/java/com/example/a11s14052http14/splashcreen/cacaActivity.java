package com.example.a11s14052http14.splashcreen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class cacaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caca);
    }
}
